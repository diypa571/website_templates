This CrazyMovie-Tempalte is for free.
Can be modified, distributed without restrictions
Have any questions?? 
Feel free to ask.
Email: diyar.parwana@gmail.com
Github: https://github.com/diypa571/
https://manpages.net/